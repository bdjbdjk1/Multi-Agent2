import asyncio
import re
from concurrent.futures import ThreadPoolExecutor

from examples.multiAgentQuestionGenerator.roles.CreatChooseRole import Teacher
from examples.multiAgentQuestionGenerator.roles.CreatSummaryRole import CreateSummaryRole
from examples.multiAgentQuestionGenerator.roles.GetPdf import GetPdf
from examples.multiAgentQuestionGenerator.roles.ReadPdf import ReadPdf
from examples.multiAgentQuestionGenerator.roles.SummaryReviewer import SummaryReviewer
from examples.multiAgentQuestionGenerator.roles.TestReviewer import Reviewer

import pdfplumber
from metagpt.team import Team

executor = ThreadPoolExecutor(max_workers=1)  # 创建线程池

# 固定的PDF文件路径
fixed_pdf_path = '基于智能体的试卷生成系统.pdf'


async def read_pdf_all_pages(pdf_path):
    loop = asyncio.get_event_loop()
    text = await loop.run_in_executor(executor, lambda: _read_pdf_all_pages(pdf_path))
    return text


def _read_pdf_all_pages(pdf_path):
    text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text += page.extract_text() + "\n"
    return text


async def process_pdf_and_simulate(investment: float = 100.0, n_round: int = 2):
    # 异步读取PDF
    pdf_text = await read_pdf_all_pages(fixed_pdf_path)  # 假设read_pdf_all_pages是一个异步函数

    # 创建团队并雇佣智能体
    team = Team()
    team.hire([ReadPdf(), CreateSummaryRole(), SummaryReviewer()])

    # 投资和启动项目
    team.invest(investment=investment)
    team.run_project(pdf_text)

    # 运行多轮模拟
    result = await team.run(n_round=n_round)  # 假设team.run是一个异步函数

    print(result)

    # 处理结果
    pattern = re.compile(r'(?<=CreateSummaryRole:).*?(?=SummaryReviewer:|$)', re.DOTALL)
    matches = pattern.finditer(result)
    last_match = next(matches, None)
    for match in matches:
        last_match = match
    if last_match:
        print("这是生成概要的结果：" + last_match.group().strip())
    else:
        print("No CreateQuestion content found.")

    return last_match.group().strip() if last_match else ""


async def question(investment: float = 100.0, n_round: int = 2, init: str = ""):
    # 创建团队并雇佣智能体
    team = Team()
    team.hire([GetPdf(), Teacher(), Reviewer()])

    # 投资和启动项目
    team.invest(investment=investment)
    team.run_project(init)

    # 运行多轮模拟
    result = await team.run(n_round=n_round)  # 假设team.run是一个异步函数
    pattern = re.compile(r'(?<=Teacher:).*?(?=Reviewer:|$)', re.DOTALL)
    matches = pattern.finditer(result)
    last_match = next(matches, None)
    for match in matches:
        last_match = match

    if last_match:
        print("这是生成的题目："+last_match.group().strip())
    else:
        print("No CreateQuestion content found.")

    return last_match.group().strip()


async def main():
    simulate_result = await process_pdf_and_simulate()
    # 正确地调用 question 函数并等待其完成
    question_result = await question(init=simulate_result)


# 运行主函数
if __name__ == "__main__":
    asyncio.run(main())
